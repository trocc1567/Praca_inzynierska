#include <atmel_start.h>
#include <avr/sleep.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uint8_t tx_buf[] = "\n\rHello AVR world ! : ";
	USART_0_write_block(tx_buf);
	/* Replace with your application code */
	sei();
	while (1) {
		Red_diode_toggle_level();
		sleep_cpu();
		
	}
}
