#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uint8_t tx_buf[] = "\n\rHello AVR world ! : ";
	USART_0_write_block(tx_buf);
	/* Replace with your application code */
	while (1) {
		if (USART_0_is_rx_ready()) 
		{
			USART_0_write(USART_0_get_data());
		}
	}
}
